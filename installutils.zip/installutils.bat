@echo off

if "%1"=="" goto help

cd root
call "..\scripts\%1.bat"
cd ..

goto ok

:help
echo Usage: installutils [packagename]

:ok