set VERSION=4.4
set FOLDER=make-%VERSION%
set TARBALL=%FOLDER%.tar.gz
set URL=https://ftp.gnu.org/gnu/make/%TARBALL%

call setup_x64
curl -LOs %URL%
tar xf %TARBALL%
del %TARBALL%

pushd %FOLDER%
	call build_w32
popd

call ..\scripts\addtopath %cd%\%FOLDER%\WinRel