@echo off
rem  This is an internal script used by installutils to add a filepath to the
rem  user %PATH%.

rem  The `reg` command may be blocked by the system. If it is, try and find
rem  another `reg` executable.
reg 2> NUL

if "%ERRORLEVEL%"=="1260" goto tryfind
set regcmd=reg

goto run

:tryfind
where reg > TMP
for /f "delims=" %%x in (TMP) do set regcmd=%%x
del TMP

:run

for /f "usebackq tokens=2,*" %%A in (`%regcmd% query HKCU\Environment /v PATH`) do set userpath=%%B

setx PATH "%userpath%%1;" > NUL

:end