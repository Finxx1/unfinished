set FILE=portable-msvc.py
set URL=https://gist.githubusercontent.com/mmozeiko/7f3162ec2988e81e56d5c4e22cde9977/raw/50d5f534519bce8c118df3e2a2bc9a6f16e29a58/%FILE%

curl -LOs %URL%
pypy %FILE% --accept-license > NUL
rd /s/q "downloads" > NUL
call ..\scripts\addtopath %cd%\msvc