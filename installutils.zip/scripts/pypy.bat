set LATEST=3.11-v7.3.18
set URL=https://downloads.python.org/pypy/pypy%LATEST%-win64.zip
set ZIPFILE=pypy%LATEST%-win64.zip
set PATHDIR=pypy%LATEST%-win64

curl -LOs %URL%
tar xf %ZIPFILE%
del %ZIPFILE%

call ..\scripts\addtopath %cd%\%PATHDIR%
